//
//  TableViewController.swift
//  How to use Simple TableView
//
//  Created by Abhishek Verma on 04/07/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    let data = ["First","Second","Third","Fourth","Fifth","Sixth"]
    let images = [UIImage(named: "1.jpg"),UIImage(named: "2.jpg"),UIImage(named: "3.jpg"),UIImage(named: "4.jpg"),UIImage(named: "5.jpg"),UIImage(named: "6.jpg")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return images.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.text = data[indexPath.row]
        
        cell?.imageView?.image = images[indexPath.row]
        
        return cell!
    }

}
